﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Generic;
using Galileo6;
using static System.Net.Mime.MediaTypeNames;
using System.CodeDom;
using System.Configuration;
using System.Diagnostics;

namespace AT1_SatelliteDataProcessing 
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        LinkedList<double> ASensor;
        LinkedList<double> BSensor;
        static int listMax = 400;
        public MainWindow()
        {
            InitializeComponent();
            populateComboBox();

            
        }

        public void populateComboBox()
        {
            sigmaBox.Items.Clear();
            for ( int i = 9; i < 76; i++ )
            {
                if (i >= 10 && i < 21)
                {
                    sigmaBox.Items.Add(i);
                }
                if (i >= 35 && i < 76)
                {
                    muBox.Items.Add(i);
                }
            }
            sigmaBox.Text = "10";

        }

        public int numberOfNodes(LinkedList<double> Sensor)
        {
            return Sensor.Count;
        }

        public void displayListboxData(LinkedList<double> Sensor, ListBox list)
        {
            list.Items.Clear();
            for (int i = 0; i < numberOfNodes(Sensor); i++)
            {
                list.Items.Add(Sensor.ElementAt(i).ToString());
            }
            
        }

        private void highlight(LinkedList<double> Sensor, ListBox list, int result) 
        {
            list.SelectedIndex = -1;

            if (result > 399)
            {
                result = 399;
            }

            list.SelectedItems.Clear();
            list.Focus();
            list.SelectedItem = list.Items[result];
            list.ScrollIntoView(list.Items[list.SelectedIndex]);

            if (result > 0 )
            {
                list.SelectedItems.Add(list.Items[result-1]);
            }
            if (result > 1)
            {
                list.SelectedItems.Add(list.Items[result - 2]);
            }
            if (result < 399)
            {
                list.SelectedItems.Add(list.Items[result + 1]);
            }
            if (result < 398)
            {
                list.SelectedItems.Add(list.Items[result + 2]);
            }
        }
        
        public void ShowAllSensorData()
        {
            for (int i = 0; i < listMax; i++)
            {
                sensorABView.Items.Add(new
                {
                    SensorA = ASensor.ElementAt(i).ToString(),
                    SensorB = BSensor.ElementAt(i).ToString(),
                });
            }
        }

        public void loadData()
        {
            ASensor = new LinkedList<double>();
            BSensor = new LinkedList<double>();
            Galileo6.ReadData readData = new Galileo6.ReadData();
            for (int i = 0; i < listMax; i++)
            {
                ASensor.AddLast(readData.SensorA(double.Parse(muBox.Text), double.Parse(sigmaBox.Text)));
                BSensor.AddLast(readData.SensorB(double.Parse(muBox.Text), double.Parse(sigmaBox.Text)));
            }
        }

        private bool selectionSort(LinkedList<double> sensor)
        {
            int min = 0;
            int max = numberOfNodes(sensor);
            for (int i = 0; i < max; i++)
            {
                min = i;
                for (int j = i+1; j < max; j++)
                {
                    if (sensor.ElementAt(j) < sensor.ElementAt(min))
                    {
                        min = j;
                    }
                }

                LinkedListNode<double> currentMin = sensor.Find(sensor.ElementAt(min));
                LinkedListNode<double> currentI = sensor.Find(sensor.ElementAt(i));

                var temp = currentMin.Value;
                currentMin.Value = currentI.Value;
                currentI.Value = temp;
            }
            return true;
        }

        private bool insertionSort(LinkedList<double> sensor)
        {
            int max = numberOfNodes(sensor);
            for (int i = 0; i < max -1; i ++)
            {
                for (int j = i+1; j > 0; j--)
                {
                    if (sensor.ElementAt(j-1) > sensor.ElementAt(j))
                    {
                        LinkedListNode<double> current = sensor.Find(sensor.ElementAt(j));
                        LinkedListNode<double> previous = sensor.Find(sensor.ElementAt(j-1));
                        var temp = previous.Value;
                        previous.Value = current.Value;
                        current.Value = temp;
                    }
                }
            }
            return true;
        }

        private int binarySearchIterative(LinkedList<double> sensor, int target, int min, int max)
        {
            int mid;
            while (min <= max-1)
            {
                mid = (min + max) / 2;
                if (target == sensor.ElementAt(mid))
                {
                    return ++mid;
                } else if (target < sensor.ElementAt(mid))
                {
                    max = mid - 1;
                } else
                {
                    min = mid +1;
                }
            }
            return min;
        }

        private int binarySearchRecursive(LinkedList<double> sensor, int target, int min, int max)
        {
            if (min <= max -1 )
            {
                int mid = (min + max) / 2;
                if (target == sensor.ElementAt(mid))
                {
                    return ++mid;
                } else if (target < sensor.ElementAt(mid))
                {
                    return binarySearchRecursive(sensor, target, min, mid - 1);
                } else
                {
                    return binarySearchRecursive(sensor, target, mid + 1, max);
                }
            }
            return min;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //Load sensor Button
        {
            loadData();
            ShowAllSensorData();
        }

        private void selBtnA_Click(object sender, RoutedEventArgs e)
        {
            selectionSort(ASensor);
            displayListboxData(ASensor, lViewA);
        }

        private void insBtnA_Click(object sender, RoutedEventArgs e)
        {
            insertionSort(ASensor);
            displayListboxData(ASensor, lViewA);
        }

        private void iteBtnA_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            if (insertionSort(ASensor) && !seaBoxA.Text.Equals(""))
            {
                sw.Reset();
                sw.Start();
                int result = binarySearchIterative(ASensor, Int32.Parse(seaBoxA.Text), 0, numberOfNodes(ASensor));
                sw.Stop();
                timeBoxA.Text = sw.Elapsed.Ticks.ToString();

                displayListboxData(ASensor, lViewA);
                highlight(ASensor, lViewA , result);

            }
            
        }

        private void recBtnA_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            if (insertionSort(ASensor) && !seaBoxA.Text.Equals(""))
            {
                sw.Reset();
                sw.Start();
                int result = binarySearchRecursive(ASensor, Int32.Parse(seaBoxA.Text), 0, numberOfNodes(ASensor));
                sw.Stop();
                timeBoxA.Text = sw.Elapsed.Ticks.ToString();

                displayListboxData(ASensor, lViewA);
                highlight(ASensor, lViewA, result);
            }
        }

        private void iteBtnB_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch sw = new Stopwatch();

            if (insertionSort(BSensor) && !seaBoxB.Text.Equals(""))
            {
                sw.Reset();
                sw.Start();
                int result = binarySearchIterative(BSensor, Int32.Parse(seaBoxB.Text), 0, numberOfNodes(BSensor));
                sw.Stop();
                timeBoxA.Text = sw.Elapsed.Ticks.ToString();

                displayListboxData(BSensor, lViewB);
                highlight(BSensor, lViewB, result);

            }
        }

        private void recBtnB_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            if (insertionSort(BSensor) && !seaBoxB.Text.Equals(""))
            {
                sw.Reset();
                sw.Start();
                int result = binarySearchRecursive(BSensor, Int32.Parse(seaBoxB.Text), 0, numberOfNodes(BSensor));
                sw.Stop();
                timeBoxA.Text = sw.Elapsed.Ticks.ToString();

                displayListboxData(BSensor, lViewA);
                highlight(BSensor, lViewB, result);

            }
        }

        private void selBtnB_Click(object sender, RoutedEventArgs e)
        {
            selectionSort(BSensor);
            displayListboxData(BSensor, lViewB);
        }

        private void insBtnB_Click(object sender, RoutedEventArgs e)
        {
            insertionSort(BSensor);
            displayListboxData(BSensor, lViewB);
        }
    }
}
