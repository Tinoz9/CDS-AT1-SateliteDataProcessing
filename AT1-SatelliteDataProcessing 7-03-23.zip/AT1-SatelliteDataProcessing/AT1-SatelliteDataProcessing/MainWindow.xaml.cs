﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Generic;
using Galileo6;
using static System.Net.Mime.MediaTypeNames;
using System.CodeDom;
using System.Configuration;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace AT1_SatelliteDataProcessing 
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //initialise the two sensor linked Lists as global variables
        LinkedList<double> ASensor = new LinkedList<double>();
        LinkedList<double> BSensor = new LinkedList<double>();

        public MainWindow()
        {
            InitializeComponent();
            populateComboBox(); //call populate combo box on main window load start up.
        }

        private void populateComboBox() //it populates the combo boxes with the approptiate data using a loop.
        {
            sigmaBox.Items.Clear();
            muBox.Items.Clear();
            for ( int i = 9; i < 76; i++ )
            {
                if (i >= 10 && i < 21)
                {
                    sigmaBox.Items.Add(i);
                }
                if (i >= 35 && i < 76)
                {
                    muBox.Items.Add(i);
                }
            }
            sigmaBox.Text = "10";
        }

        private int numberOfNodes(LinkedList<double> Sensor) //method receives a linked list then returns the amount of nodes in the list.
        {
            return Sensor.Count;
        }

        public void displayListboxData(LinkedList<double> Sensor, ListBox list) //receive a linked list and a listbox then will display the contents of the linked list into the list.
        {
            list.Items.Clear();
            for (int i = 0; i < numberOfNodes(Sensor); i++)
            {
                list.Items.Add(Sensor.ElementAt(i).ToString());
            }
            
        }

        private void highlight(LinkedList<double> Sensor, ListBox list, int result) //will select the surrounding values of a given value in the given list.
        {
            list.SelectedIndex = -1;

            if (result > 399)
            {
                result = 399;
            }

            list.SelectedItems.Clear();
            list.Focus();
            list.SelectedItem = list.Items[result];
            list.ScrollIntoView(list.Items[list.SelectedIndex]);

            if (result > 0 )
            {
                list.SelectedItems.Add(list.Items[result-1]);
            }
            if (result > 1)
            {
                list.SelectedItems.Add(list.Items[result - 2]);
            }
            if (result < 399)
            {
                list.SelectedItems.Add(list.Items[result + 1]);
            }
            if (result < 398)
            {
                list.SelectedItems.Add(list.Items[result + 2]);
            }
        }
        
        private void ShowAllSensorData() //will display all of the the unsorted sensor data in the mixed list view.
        {
            int node = numberOfNodes(ASensor);
            for (int i = 0; i < node; i++)
            {
                sensorABView.Items.Add(new
                {
                    SensorA = ASensor.ElementAt(i).ToString(),
                    SensorB = BSensor.ElementAt(i).ToString(),
                });
            }
        }

        private void loadData() //initialise the lists then will read the data from galileo.dll and add it to the lists.
        {
            
            Galileo6.ReadData readData = new Galileo6.ReadData();
            for (int i = 0; i < 400; i++)
            {
                ASensor.AddLast(readData.SensorA(double.Parse(muBox.Text), double.Parse(sigmaBox.Text)));
                BSensor.AddLast(readData.SensorB(double.Parse(muBox.Text), double.Parse(sigmaBox.Text)));
            }
        }

        private bool selectionSort(LinkedList<double> sensor) //selection sort of given list.
        {
            int min = 0;
            int max = numberOfNodes(sensor);
            for (int i = 0; i < max; i++)
            {
                min = i;
                for (int j = i+1; j < max; j++)
                {
                    if (sensor.ElementAt(j) < sensor.ElementAt(min))
                    {
                        min = j;
                    }
                }

                LinkedListNode<double> currentMin = sensor.Find(sensor.ElementAt(min));
                LinkedListNode<double> currentI = sensor.Find(sensor.ElementAt(i));

                var temp = currentMin.Value;
                currentMin.Value = currentI.Value;
                currentI.Value = temp;
            }
            return true;
        }

        private bool insertionSort(LinkedList<double> sensor) //insertion sort of given list.
        {

            int max = numberOfNodes(sensor);
            for (int i = 0; i < max - 1; i++)
            {
                for (int j = i + 1; j > 0; j--)
                {
                    if (sensor.ElementAt(j - 1) > sensor.ElementAt(j))
                    {
                        LinkedListNode<double> current = sensor.Find(sensor.ElementAt(j));
                        LinkedListNode<double> previous = sensor.Find(sensor.ElementAt(j - 1));
                        var temp = previous.Value;
                        previous.Value = current.Value;
                        current.Value = temp;
                    }
                }
            }
            return true;

        }

        private int binarySearchIterative(LinkedList<double> sensor, int target, int min, int max) //recevies the linked list, target minimum and maximum then performs binary search of given list and returns the closest value.
        {
            int mid;
            while (min <= max-1)
            {
                mid = (min + max) / 2;
                if (target == sensor.ElementAt(mid))
                {
                    return ++mid;
                } else if (target < sensor.ElementAt(mid))
                {
                    max = mid - 1;
                } else
                {
                    min = mid +1;
                }
            }
            return min;
        }

        private int binarySearchRecursive(LinkedList<double> sensor, int target, int min, int max) //performs binary search by layering mulitple methods until it will eventually find the closest value and then every method will finish and the value will be displayed.
        {
            if (min <= max -1 )
            {
                int mid = (min + max) / 2;
                if (target == sensor.ElementAt(mid))
                {
                    return ++mid;
                } else if (target < sensor.ElementAt(mid))
                {
                    return binarySearchRecursive(sensor, target, min, mid - 1);
                } else
                {
                    return binarySearchRecursive(sensor, target, mid + 1, max);
                }
            }
            return min;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //Load sensor Button calls the loadData() method and the ShowAllSensorData() method.
        {
            loadData();
            ShowAllSensorData();
        }

        private void selBtnA_Click(object sender, RoutedEventArgs e) //begins a stop watch, performs selection sort, then it will display the results of the sort and the time it took to perform the sort in milliseconds.
        {
            Stopwatch sw = new Stopwatch();
            sw.Reset();
            sw.Start();
            selectionSort(ASensor);
            sw.Stop();
            timeBoxA.Text = sw.Elapsed.Milliseconds.ToString() + " Milliseconds";
            displayListboxData(ASensor, lViewA);
        }

        private void insBtnA_Click(object sender, RoutedEventArgs e) //same as selection sort for insertion sort. 
        {
            Stopwatch sw = new Stopwatch();
            sw.Reset();
            sw.Start();
            insertionSort(ASensor);
            sw.Stop();
            timeBoxA.Text = sw.Elapsed.Milliseconds.ToString() + " Milliseconds";
            displayListboxData(ASensor, lViewA);
        }

        //iterative search button will check to see of the data is sorted then it will begin a stop watch and call the search method for sensorA then it will display the time it took in ticks in the text box. 
        //it will display the result of the search by calling the highlight method parsing the result of the search.
        private void iteBtnA_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            if (insertionSort(ASensor) && !seaBoxA.Text.Equals(null))
            {
                sw.Reset();
                sw.Start();
                int result = 999;
                int target;
                if (Int32.TryParse(seaBoxA.Text, out target))
                {
                    result = binarySearchIterative(ASensor, target, 0, numberOfNodes(ASensor));
                }
                sw.Stop();
                timeBoxA.Text = sw.Elapsed.Ticks.ToString() + " Ticks";

                displayListboxData(ASensor, lViewA);
                highlight(ASensor, lViewA , result);

            }
            
        }

        //recursive search atlternative of iterative search.
        private void recBtnA_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            if (insertionSort(ASensor) && !seaBoxA.Text.Equals(""))
            {
                
                sw.Reset();
                sw.Start();
                int result = 999;
                int target;
                if (Int32.TryParse(seaBoxA.Text, out target))
                {
                    result = binarySearchRecursive(ASensor, target, 0, numberOfNodes(ASensor));
                }
                
                sw.Stop();
                timeBoxA.Text = sw.Elapsed.Ticks.ToString() + " Ticks";

                displayListboxData(ASensor, lViewA);
                highlight(ASensor, lViewA, result);
            }
        }
        
        //sensorB alternative of iterative search.
        private void iteBtnB_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch sw = new Stopwatch();

            if (insertionSort(BSensor) && !seaBoxB.Text.Equals(""))
            {
                sw.Reset();
                sw.Start();
                int result = 999;
                int target;
                if (Int32.TryParse(seaBoxB.Text, out target))
                {
                    result = binarySearchIterative(BSensor, target, 0, numberOfNodes(BSensor));
                }
                sw.Stop();
                timeBoxB.Text = sw.Elapsed.Ticks.ToString() + " Ticks";

                displayListboxData(BSensor, lViewB);
                highlight(BSensor, lViewB, result);

            }
        }

        //sensorB alterative of recursive search.
        private void recBtnB_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            if (insertionSort(BSensor) && !seaBoxB.Text.Equals(""))
            {
                sw.Reset();
                sw.Start();
                int result = 999;
                int target;
                if (Int32.TryParse(seaBoxB.Text, out target))
                {
                    result = binarySearchRecursive(BSensor, target, 0, numberOfNodes(BSensor));
                }
                sw.Stop();
                timeBoxB.Text = sw.Elapsed.Ticks.ToString() + " Ticks";

                displayListboxData(BSensor, lViewA);
                highlight(BSensor, lViewB, result);

            }
        }

        private void selBtnB_Click(object sender, RoutedEventArgs e) //selection sort of sensorB
        {
            Stopwatch sw = new Stopwatch();
            sw.Reset();
            sw.Start();
            selectionSort(BSensor);
            sw.Stop();
            timeBoxB.Text = sw.Elapsed.Milliseconds.ToString() + " Milliseconds";
            displayListboxData(BSensor, lViewB);
        }

        private void insBtnB_Click(object sender, RoutedEventArgs e) //insertion sort for sensorB
        {
            Stopwatch sw = new Stopwatch();
            sw.Reset();
            sw.Start();
            insertionSort(BSensor);
            sw.Stop();
            timeBoxB.Text = sw.Elapsed.Milliseconds.ToString() + " Milliseconds";
            displayListboxData(BSensor, lViewB);
        }

        private async void seaBoxA_TextChanged(object sender, TextChangedEventArgs e) //search box text change event. calls int only method parsing current text.
        {
            seaBoxA.Text = intOnly(seaBoxA.Text);
        }

        private void seaBoxB_TextChanged(object sender, TextChangedEventArgs e) //search box text change event. calls int only method parsing current text.
        {
            seaBoxB.Text = intOnly(seaBoxB.Text);
        }

        //creates regex filter which will check to see if the current text matches with the regex filter.
        //if not then the text box is cleared. a pain i know but i could not find a cleaner solution
        private string intOnly(string s) 
        {
            Regex regex = new Regex("^(?:-(?:[1-9](?:\\d{0,2}(?:,\\d{3})+|\\d*))|(?:0|(?:[1-9](?:\\d{0,2}(?:,\\d{3})+|\\d*))))(?:.\\d+|)$");
            if (!regex.IsMatch(seaBoxA.Text))
            {
                s = "";
            }
            return s;
        }
    }
}
