﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Generic;
using Galileo6;
using static System.Net.Mime.MediaTypeNames;
using System.CodeDom;

namespace AT1_SatelliteDataProcessing 
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        LinkedList<double> ASensor;
        LinkedList<double> BSensor;
        static int listMax = 400;
        public MainWindow()
        {
            InitializeComponent();
            populateComboBox();

            
        }

        public void populateComboBox()
        {
            sigmaBox.Items.Clear();
            for ( int i = 10; i < 75; i++ )
            {
                if (i >= 10 && i < 21)
                {
                    sigmaBox.Items.Add(i);
                }
                if (i >= 35 && i < 76)
                {
                    muBox.Items.Add(i);
                }
            }
        }

        public int numberOfNodes(LinkedList<double> Sensor)
        {
            return Sensor.Count;
        }

        public void displayListboxData(LinkedList<double> Sensor, ListBox list)
        {
            for (int i = 0; i < numberOfNodes(Sensor); i++)
            {
                list.Items.Add(Sensor);
            }
            
        }
        
        public void ShowAllSensorData()
        {
            for (int i = 0; i < listMax; i++)
            {
                sensorABView.Items.Add(new
                {
                    SensorA = ASensor.ElementAt(i).ToString(),
                    SensorB = BSensor.ElementAt(i).ToString(),
                });
            }
        }

        public void loadData()
        {
            ASensor = new LinkedList<double>();
            BSensor = new LinkedList<double>();
            Galileo6.ReadData readData = new Galileo6.ReadData();
            for (int i = 0; i < listMax; i++)
            {
                ASensor.AddLast(readData.SensorA(double.Parse(muBox.Text), double.Parse(sigmaBox.Text)));
                BSensor.AddLast(readData.SensorB(double.Parse(muBox.Text), double.Parse(sigmaBox.Text)));
            }
        }

        private bool selectionSort(LinkedList<double> sensor)
        {
            int min = 0;
            int max = numberOfNodes(sensor);
            for (int i = 0; i < max; i++)
            {
                min = i;
                for (int j = i+1; j < max; j++)
                {
                    if (sensor.ElementAt(j) < sensor.ElementAt(min))
                    {
                        min = j;
                    }
                }

                LinkedListNode<double> currentMin = sensor.Find(sensor.ElementAt(min));
                LinkedListNode<double> currentI = sensor.Find(sensor.ElementAt(i));

                var temp = currentMin.Value;
                currentMin.Value = temp;
                currentI.Value = temp;
            }
            return true;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //Load sensor Button
        {
            loadData();
            ShowAllSensorData();
        }
    }
}
