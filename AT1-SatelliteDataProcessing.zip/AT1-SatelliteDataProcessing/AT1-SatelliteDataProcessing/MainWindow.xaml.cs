﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Generic;
using Galileo6;
using static System.Net.Mime.MediaTypeNames;

namespace AT1_SatelliteDataProcessing 
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        LinkedList<double> ASensor;
        LinkedList<double> BSensor;
        public MainWindow()
        {
            InitializeComponent();
        }



        public void loadData()
        {
            ASensor = new LinkedList<double>();
            BSensor = new LinkedList<double>();
            Galileo6.ReadData readData = new Galileo6.ReadData();
            for (int i = 0; i < 400; i++)
            {
                ASensor.AddLast(readData.SensorA(double.Parse(muBox.Text), double.Parse(sigmaBox.Text)));
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
